package com.cdac.cntr;
 import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.Product;
import com.cdac.dto.User;
import com.cdac.service.ProductService;
import com.cdac.service.UserService;
import com.cdac.valid.UserValidator;

@Controller
public class userController {
    
	
	@Autowired
	private UserService userService;
	 @Autowired
	  private ProductService productService;
	@Autowired
	private UserValidator userValidator;

	@RequestMapping(value = "/prep_reg_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
	    
		map.put("user", new User());
		return "reg_form";
	}
	
	@RequestMapping(value = "/reg.htm",method = RequestMethod.POST)
	public String register(  User user, BindingResult rs, ModelMap map) {
		 userValidator.validate(user, rs); 
		 if(rs.hasErrors())
		 { return
				  "reg_form"; 
		 }
		userService.addUser(user);
		return "index";
	}

	@RequestMapping(value = "/prep_log_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("user", new User());
		return "login_form";
	}

	@RequestMapping(value = "/login.htm",method = RequestMethod.POST)
	public String login(User user,BindingResult result,ModelMap map,HttpSession session) {
		
		  userValidator.validate(user, result); if(result.hasErrors()) { return
		  "login_form"; }
		 
		
		boolean b = userService.findUser(user);
		if(b) {
			session.setAttribute("user", user); 
			return "home";
		}else {
			map.put("user", new User());
			return "login_form";
		}
	}
	
	
	
	
	
	
	@RequestMapping(value = "/prep_product_form.htm",method = RequestMethod.GET)
	public String prepProductForm(ModelMap map) {
	    
		map.put("product", new Product());
		return "add_item_form";
	}
	@RequestMapping(value = "/productadd.htm",method = RequestMethod.POST)
	public String addproduct( Product product, ModelMap map) {
 		  
		 productService.inserItem(product);
		return "index";
	}
	
	@RequestMapping(value = "/show_product_form.htm", method = RequestMethod.GET)
	public String prepareproductList(ModelMap map, HttpSession session) {
	//	int userId = ((User) session.getAttribute("user")).getUserId();
		List<Product> list = productService.selectAll();

		map.put("productlist", list);
		return "showlist";
	}
	
	
	
	@RequestMapping(value = "product_update.htm", method = RequestMethod.GET)
	public String prepareUpdate(@RequestParam int productId, ModelMap map) {
		Product f = productService.findProduct(productId);
		map.put("productp", f);
		return "updateList";
	}

	@RequestMapping(value = "product_update1.htm", method = RequestMethod.GET)
	public String updateproduct(ModelMap map, Product product, HttpSession session) {
		//int userId = ((User) session.getAttribute("user")).getUserId();
		//flight.setUserId(userId);
		//flightservice.modify(flight);
           productService.updateItem(product);
		List<Product> list = productService.selectAll();

		map.put("productlist", list);
		return "showlist";
	}
	 
	
}
