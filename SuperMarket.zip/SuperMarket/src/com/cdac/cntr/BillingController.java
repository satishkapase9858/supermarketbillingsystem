package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.dto.Customer;
import com.cdac.dto.Item;
import com.cdac.dto.Product;
import com.cdac.dto.User;
import com.cdac.service.CustomerService;
import com.cdac.service.ItemService;
import com.cdac.service.ProductService;

@Controller
public class BillingController {
    @Autowired
    private CustomerService customerService;
     @Autowired
      private ItemService itemService;
     @Autowired
       private ProductService productService;

 	@RequestMapping(value = "/pre_billing_form.htm",method = RequestMethod.GET)
 	public String prepRegFormgg(ModelMap map) {
 	 
      map.put("customer",new Customer());

             return "customer_form";
            		 
 	}
 	

	@RequestMapping(value = "/customer.htm",method = RequestMethod.POST)
	public String register11( Customer customer, ModelMap map,HttpSession session) {
		session.setAttribute("customer", customer); 

		List<Product> list = productService.selectAll();
		map.put("productlist", list);

		customerService.insertcustomer(customer);
		return "item_form";
	}
	 @RequestMapping(value="/item_insert.htm",method=RequestMethod.POST)
	   public String adddd(List<Item>list,ModelMap map)
	   {  
		for(Item i:list) { 
	   itemService.insert(i);
 		  
		}
		return "item_form";
	 	 
	   }
     
     
     
     
     
     
     
}
