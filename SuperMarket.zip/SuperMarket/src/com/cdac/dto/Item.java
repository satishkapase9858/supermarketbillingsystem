package com.cdac.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Item22")
public class Item {
	  @Id
	   @GeneratedValue
	  private int itemId;
	    private String itemName;
	     private float price;
	            private int customerId;
			public Item() {
				super();
				// TODO Auto-generated constructor stub
			}
			public Item(int itemId, String itemName, float price, int quantity, float total, int customerId) {
				super();
				this.itemId = itemId;
				this.itemName = itemName;
				this.price = price;
				 
				this.customerId = customerId;
			}
			public int getItemId() {
				return itemId;
			}
			public void setItemId(int itemId) {
				this.itemId = itemId;
			}
			public String getItemName() {
				return itemName;
			}
			public void setItemName(String itemName) {
				this.itemName = itemName;
			}
			public float getPrice() {
				return price;
			}
			public void setPrice(float price) {
				this.price = price;
			}
		 
			
			@Override
			public String toString() {
				return "Item [itemId=" + itemId + ", itemName=" + itemName + ", price=" + price + ", customerId="
						+ customerId + "]";
			}
			public int getCustomerId() {
				return customerId;
			}
			public void setCustomerId(int customerId) {
				this.customerId = customerId;
			}
			 
	        
	 

}
