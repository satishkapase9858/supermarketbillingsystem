package com.cdac.dto;

 import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="UserInfo")
public class User {
	  @Id
	   @GeneratedValue
   private int  userId;
	  @Column(name="username")
	        private String userName;
	  @Column(name="mobileno")

      private int mobileNo;
	           private String date;
	     	  @Column(name="email")

       private String email;
	    	  @Column(name="password")

         private String passWord;
			public User() {
				super();
				// TODO Auto-generated constructor stub
			}
			public int getUserId() {
				return userId;
			}
			public void setUserId(int userId) {
				this.userId = userId;
			}
			public String getUserName() {
				return userName;
			}
			public void setUserName(String userName) {
				this.userName = userName;
			}
			public int getMobileNo() {
				return mobileNo;
			}
			public void setMobileNo(int mobileNo) {
				this.mobileNo = mobileNo;
			}
			public String getDate() {
				return date;
			}
			public void setDate(String date) {
				this.date = date;
			}
			public String getEmail() {
				return email;
			}
			public void setEmail(String email) {
				this.email = email;
			}
			public String getPassWord() {
				return passWord;
			}
			public void setPassWord(String passWord) {
				this.passWord = passWord;
			}
	           
	           
}
