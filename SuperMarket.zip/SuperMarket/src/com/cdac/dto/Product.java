package com.cdac.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
 @Table(name="Product")
public class Product {
	@Id
	@GeneratedValue
	private int productId;
	  private String name;
	   private  String company;
	    public Product(int productId) {
		super();
		this.productId = productId;
	}
		@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", company=" + company + ", productQnty="
				+ productQnty + ", price=" + price + "]";
	}
		public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public int getProductQnty() {
		return productQnty;
	}
	public void setProductQnty(int productQnty) {
		this.productQnty = productQnty;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
		public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
		private int productQnty;
	     private float price;

}
