package com.cdac.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cdac.dto.User;
@Service
public class UserValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
  		return clazz.equals(User.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
 		  ValidationUtils.rejectIfEmpty(errors, "userName", "username", "Username should not contain empty field");
 		  ValidationUtils.rejectIfEmpty(errors, "passWord", "password", "  field  should not contain empty field");
 		    User user=(User)target;
 		    
 		    if(user.getUserName()!=null  )
 		      {
 		    	  if((user.getUserName().length())<10  )
 		    	     errors.rejectValue("userName", "username", "username require at least 10 and maximum 20 character or number");
 	 
 		      }
 		   if(user.getPassWord()!=null)
		      {
		    	  if( (user.getPassWord().length())<5 )
		    	     errors.rejectValue("passWord", "password", "pass require at least 5 and maximum 10 character or number");
	 
		      }
 		  if(user.getEmail()!=null)
	      {
	    	   String emails=user.getEmail();
	    	    String regex="^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+";
	    	      boolean results=emails.matches(regex);
	    	        if(!results) {
	    	        	errors.rejectValue("email", emails, "Email is not valid");
	    	        	
	    	        }
 
	      }
 		  
 		  if(user.getMobileNo()!=0)
	      {
 			 int phones=user.getMobileNo();
	    	   String phn=String.valueOf(phones)  ;
 			 String regex= "(0/91)?[7-9][0-9]{9}";
	    	      boolean results=phn.matches(regex);
	    	        if(!results) {
	    	        	 errors.rejectValue("mobileNo", "mobileno","mobile is not valid");
	    	        	
	    	        }
	      }
		
	}
	

}
