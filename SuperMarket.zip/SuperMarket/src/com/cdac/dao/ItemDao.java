package com.cdac.dao;

import com.cdac.dto.Item;

public interface ItemDao {
    public void insert( Item item);
          

}
