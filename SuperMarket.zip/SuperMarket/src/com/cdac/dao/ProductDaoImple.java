package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Product;
@Repository
public class ProductDaoImple implements ProductDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void inserItem(Product product) {
		
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(product);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public void deleteItem(int productId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Product(productId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}
	  
  @Override
	public void updateItem(Product product) {
     
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				
				Product ex = (Product)session.get(Product.class, product.getProductId());
				ex.setName(product.getName());
				ex.setPrice(product.getPrice());
				ex.setCompany(product.getCompany());
				  ex.setProductQnty(product.getProductQnty());
				
				session.update(product);
				
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}

	@Override
	public List<Product> selectAll() {
		List<Product> list = hibernateTemplate.execute(new HibernateCallback<List<Product>>() {

			@Override
			public List<Product> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				org.hibernate.Query q = session.createQuery("from Product ");
			

				List<Product> li = q.list();
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		return list;
	}

	@Override
	public Product findProduct(int productId) {
		Product p = hibernateTemplate.execute(new HibernateCallback<Product>() {

			@Override
			public Product doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				org.hibernate.Query q = session.createQuery("from Product where productId=? ");
			       q.setInteger(0, productId);

			       Product pp = ( Product) session.get( Product.class, productId);
				tr.commit();
				session.flush();
				session.close();
				return pp;
			}
		});
		return p;
	}

}


