package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Product;

public interface ProductDao {
	  public void inserItem(Product product);
	    public void deleteItem(int productId);
         public List<Product> selectAll();
		 public  void updateItem(Product product);
		  public Product findProduct(int productId);
         
}
