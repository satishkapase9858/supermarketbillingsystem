package com.cdac.dao;

import com.cdac.dto.Customer;

public interface CustomerDao {
   public void insertcustomer(Customer customer);
    
}
