package com.cdac.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.ItemDao;
import com.cdac.dto.Item;
@Service
public class ItemServiceImple implements ItemService {
     @Autowired
       ItemDao itemDao;
	@Override
	public void insert(Item item) {
        itemDao.insert(  item);

	}

}
