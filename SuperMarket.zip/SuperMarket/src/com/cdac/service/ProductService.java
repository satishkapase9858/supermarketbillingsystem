package com.cdac.service;

import java.util.List;

import com.cdac.dao.ProductDao;
import com.cdac.dto.Product;

public interface ProductService {
	 
	public void inserItem(Product product);
    public void deleteItem(int productId);
    public void updateItem(Product product);
    public List<Product> selectAll();
	  public Product findProduct(int productId);
	
    	
    	
    	
    }

