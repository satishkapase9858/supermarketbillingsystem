package com.cdac.service;

import com.cdac.dto.Customer;

public interface CustomerService {
	   public void insertcustomer(Customer customer);

	    

}
