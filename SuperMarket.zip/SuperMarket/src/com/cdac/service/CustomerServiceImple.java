package com.cdac.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.CustomerDao;
import com.cdac.dto.Customer;
@Service
public class CustomerServiceImple implements CustomerService{
         @Autowired CustomerDao customerDao;
	     @Override
	public void insertcustomer(Customer customer) {
 		  customerDao.insertcustomer(customer);
	}
	

}
