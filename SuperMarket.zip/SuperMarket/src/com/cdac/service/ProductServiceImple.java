package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.ProductDao;
import com.cdac.dto.Product;
@Service
public class ProductServiceImple implements ProductService {
    @Autowired
      private ProductDao productDao;
	@Override
	public void inserItem(Product product) {
		productDao.inserItem(product);
	}

	@Override
	public void deleteItem(int productId) {
		productDao.deleteItem(productId);
		
	}

	 

	@Override
	public List<Product> selectAll() {
		return productDao.selectAll();
	}

	@Override
	public void updateItem(Product product) {
		productDao.updateItem(product);
		
	}

	@Override
	public Product findProduct(int productId) {
 		return productDao.findProduct( productId);

	}

}
