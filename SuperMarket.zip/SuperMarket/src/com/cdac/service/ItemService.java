package com.cdac.service;

import com.cdac.dto.Item;

public interface ItemService {
    public void insert( Item item);


}
